--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "EuropeanSoccer_DB";
--
-- Name: EuropeanSoccer_DB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "EuropeanSoccer_DB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "EuropeanSoccer_DB" OWNER TO postgres;

\connect "EuropeanSoccer_DB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: android_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.android_metadata (
    locale text
);


ALTER TABLE public.android_metadata OWNER TO postgres;

--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: country_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.country_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.country_id_seq OWNER TO postgres;

--
-- Name: country_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.country_id_seq OWNED BY public.country.id;


--
-- Name: league; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.league (
    id integer NOT NULL,
    country_id integer,
    name text
);


ALTER TABLE public.league OWNER TO postgres;

--
-- Name: league_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.league_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.league_id_seq OWNER TO postgres;

--
-- Name: league_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.league_id_seq OWNED BY public.league.id;


--
-- Name: match; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.match (
    id integer NOT NULL,
    country_id integer,
    league_id integer,
    season text,
    stage integer,
    date text,
    match_api_id integer,
    home_team_api_id integer,
    away_team_api_id integer,
    home_team_goal integer,
    away_team_goal integer,
    home_player_x1 integer,
    home_player_x2 integer,
    home_player_x3 integer,
    home_player_x4 integer,
    home_player_x5 integer,
    home_player_x6 integer,
    home_player_x7 integer,
    home_player_x8 integer,
    home_player_x9 integer,
    home_player_x10 integer,
    home_player_x11 integer,
    away_player_x1 integer,
    away_player_x2 integer,
    away_player_x3 integer,
    away_player_x4 integer,
    away_player_x5 integer,
    away_player_x6 integer,
    away_player_x7 integer,
    away_player_x8 integer,
    away_player_x9 integer,
    away_player_x10 integer,
    away_player_x11 integer,
    home_player_y1 integer,
    home_player_y2 integer,
    home_player_y3 integer,
    home_player_y4 integer,
    home_player_y5 integer,
    home_player_y6 integer,
    home_player_y7 integer,
    home_player_y8 integer,
    home_player_y9 integer,
    home_player_y10 integer,
    home_player_y11 integer,
    away_player_y1 integer,
    away_player_y2 integer,
    away_player_y3 integer,
    away_player_y4 integer,
    away_player_y5 integer,
    away_player_y6 integer,
    away_player_y7 integer,
    away_player_y8 integer,
    away_player_y9 integer,
    away_player_y10 integer,
    away_player_y11 integer,
    home_player_1 integer,
    home_player_2 integer,
    home_player_3 integer,
    home_player_4 integer,
    home_player_5 integer,
    home_player_6 integer,
    home_player_7 integer,
    home_player_8 integer,
    home_player_9 integer,
    home_player_10 integer,
    home_player_11 integer,
    away_player_1 integer,
    away_player_2 integer,
    away_player_3 integer,
    away_player_4 integer,
    away_player_5 integer,
    away_player_6 integer,
    away_player_7 integer,
    away_player_8 integer,
    away_player_9 integer,
    away_player_10 integer,
    away_player_11 integer,
    goal text,
    shoton text,
    shotoff text,
    foulcommit text,
    card text,
    cross_ text,
    corner text,
    possession text,
    b365h numeric,
    b365d numeric,
    b365a numeric,
    bwh numeric,
    bwd numeric,
    bwa numeric,
    iwh numeric,
    iwd numeric,
    iwa numeric,
    lbh numeric,
    lbd numeric,
    lba numeric,
    psh numeric,
    psd numeric,
    psa numeric,
    whh numeric,
    whd numeric,
    wha numeric,
    sjh numeric,
    sjd numeric,
    sja numeric,
    vch numeric,
    vcd numeric,
    vca numeric,
    gbh numeric,
    gbd numeric,
    gba numeric,
    bsh numeric,
    bsd numeric,
    bsa numeric
);


ALTER TABLE public.match OWNER TO postgres;

--
-- Name: match_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.match_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.match_id_seq OWNER TO postgres;

--
-- Name: match_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.match_id_seq OWNED BY public.match.id;


--
-- Name: player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player (
    id integer NOT NULL,
    player_api_id integer,
    player_name text,
    player_fifa_api_id integer,
    birthday text,
    height real,
    weight integer
);


ALTER TABLE public.player OWNER TO postgres;

--
-- Name: player_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player_attributes (
    id integer NOT NULL,
    player_fifa_api_id integer,
    player_api_id integer,
    date text,
    overall_rating integer,
    potential integer,
    preferred_foot text,
    attacking_work_rate text,
    defensive_work_rate text,
    crossing integer,
    finishing integer,
    heading_accuracy integer,
    short_passing integer,
    volleys integer,
    dribbling integer,
    curve integer,
    free_kick_accuracy integer,
    long_passing integer,
    ball_control integer,
    acceleration integer,
    sprint_speed integer,
    agility integer,
    reactions integer,
    balance integer,
    shot_power integer,
    jumping integer,
    stamina integer,
    strength integer,
    long_shots integer,
    aggression integer,
    interceptions integer,
    positioning integer,
    vision integer,
    penalties integer,
    marking integer,
    standing_tackle integer,
    sliding_tackle integer,
    gk_diving integer,
    gk_handling integer,
    gk_kicking integer,
    gk_positioning integer,
    gk_reflexes integer
);


ALTER TABLE public.player_attributes OWNER TO postgres;

--
-- Name: player_attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.player_attributes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.player_attributes_id_seq OWNER TO postgres;

--
-- Name: player_attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.player_attributes_id_seq OWNED BY public.player_attributes.id;


--
-- Name: player_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.player_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.player_id_seq OWNER TO postgres;

--
-- Name: player_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.player_id_seq OWNED BY public.player.id;


--
-- Name: team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team (
    id integer NOT NULL,
    team_api_id integer,
    team_fifa_api_id integer,
    team_long_name text,
    team_short_name text
);


ALTER TABLE public.team OWNER TO postgres;

--
-- Name: team_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_attributes (
    id integer NOT NULL,
    team_fifa_api_id integer,
    team_api_id integer,
    date text,
    buildupplayspeed integer,
    buildupplayspeedclass text,
    buildupplaydribbling integer,
    buildupplaydribblingclass text,
    buildupplaypassing integer,
    buildupplaypassingclass text,
    buildupplaypositioningclass text,
    chancecreationpassing integer,
    chancecreationpassingclass text,
    chancecreationcrossing integer,
    chancecreationcrossingclass text,
    chancecreationshooting integer,
    chancecreationshootingclass text,
    chancecreationpositioningclass text,
    defencepressure integer,
    defencepressureclass text,
    defenceaggression integer,
    defenceaggressionclass text,
    defenceteamwidth integer,
    defenceteamwidthclass text,
    defencedefenderlineclass text
);


ALTER TABLE public.team_attributes OWNER TO postgres;

--
-- Name: team_attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_attributes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_attributes_id_seq OWNER TO postgres;

--
-- Name: team_attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_attributes_id_seq OWNED BY public.team_attributes.id;


--
-- Name: team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_id_seq OWNER TO postgres;

--
-- Name: team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_id_seq OWNED BY public.team.id;


--
-- Name: country id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country ALTER COLUMN id SET DEFAULT nextval('public.country_id_seq'::regclass);


--
-- Name: league id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.league ALTER COLUMN id SET DEFAULT nextval('public.league_id_seq'::regclass);


--
-- Name: match id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match ALTER COLUMN id SET DEFAULT nextval('public.match_id_seq'::regclass);


--
-- Name: player id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player ALTER COLUMN id SET DEFAULT nextval('public.player_id_seq'::regclass);


--
-- Name: player_attributes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_attributes ALTER COLUMN id SET DEFAULT nextval('public.player_attributes_id_seq'::regclass);


--
-- Name: team id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team ALTER COLUMN id SET DEFAULT nextval('public.team_id_seq'::regclass);


--
-- Name: team_attributes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_attributes ALTER COLUMN id SET DEFAULT nextval('public.team_attributes_id_seq'::regclass);


--
-- Data for Name: android_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.android_metadata (locale) FROM stdin;
\.
COPY public.android_metadata (locale) FROM '$$PATH$$/3412.dat';

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country (id, name) FROM stdin;
\.
COPY public.country (id, name) FROM '$$PATH$$/3414.dat';

--
-- Data for Name: league; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.league (id, country_id, name) FROM stdin;
\.
COPY public.league (id, country_id, name) FROM '$$PATH$$/3416.dat';

--
-- Data for Name: match; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.match (id, country_id, league_id, season, stage, date, match_api_id, home_team_api_id, away_team_api_id, home_team_goal, away_team_goal, home_player_x1, home_player_x2, home_player_x3, home_player_x4, home_player_x5, home_player_x6, home_player_x7, home_player_x8, home_player_x9, home_player_x10, home_player_x11, away_player_x1, away_player_x2, away_player_x3, away_player_x4, away_player_x5, away_player_x6, away_player_x7, away_player_x8, away_player_x9, away_player_x10, away_player_x11, home_player_y1, home_player_y2, home_player_y3, home_player_y4, home_player_y5, home_player_y6, home_player_y7, home_player_y8, home_player_y9, home_player_y10, home_player_y11, away_player_y1, away_player_y2, away_player_y3, away_player_y4, away_player_y5, away_player_y6, away_player_y7, away_player_y8, away_player_y9, away_player_y10, away_player_y11, home_player_1, home_player_2, home_player_3, home_player_4, home_player_5, home_player_6, home_player_7, home_player_8, home_player_9, home_player_10, home_player_11, away_player_1, away_player_2, away_player_3, away_player_4, away_player_5, away_player_6, away_player_7, away_player_8, away_player_9, away_player_10, away_player_11, goal, shoton, shotoff, foulcommit, card, cross_, corner, possession, b365h, b365d, b365a, bwh, bwd, bwa, iwh, iwd, iwa, lbh, lbd, lba, psh, psd, psa, whh, whd, wha, sjh, sjd, sja, vch, vcd, vca, gbh, gbd, gba, bsh, bsd, bsa) FROM stdin;
\.
COPY public.match (id, country_id, league_id, season, stage, date, match_api_id, home_team_api_id, away_team_api_id, home_team_goal, away_team_goal, home_player_x1, home_player_x2, home_player_x3, home_player_x4, home_player_x5, home_player_x6, home_player_x7, home_player_x8, home_player_x9, home_player_x10, home_player_x11, away_player_x1, away_player_x2, away_player_x3, away_player_x4, away_player_x5, away_player_x6, away_player_x7, away_player_x8, away_player_x9, away_player_x10, away_player_x11, home_player_y1, home_player_y2, home_player_y3, home_player_y4, home_player_y5, home_player_y6, home_player_y7, home_player_y8, home_player_y9, home_player_y10, home_player_y11, away_player_y1, away_player_y2, away_player_y3, away_player_y4, away_player_y5, away_player_y6, away_player_y7, away_player_y8, away_player_y9, away_player_y10, away_player_y11, home_player_1, home_player_2, home_player_3, home_player_4, home_player_5, home_player_6, home_player_7, home_player_8, home_player_9, home_player_10, home_player_11, away_player_1, away_player_2, away_player_3, away_player_4, away_player_5, away_player_6, away_player_7, away_player_8, away_player_9, away_player_10, away_player_11, goal, shoton, shotoff, foulcommit, card, cross_, corner, possession, b365h, b365d, b365a, bwh, bwd, bwa, iwh, iwd, iwa, lbh, lbd, lba, psh, psd, psa, whh, whd, wha, sjh, sjd, sja, vch, vcd, vca, gbh, gbd, gba, bsh, bsd, bsa) FROM '$$PATH$$/3422.dat';

--
-- Data for Name: player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player (id, player_api_id, player_name, player_fifa_api_id, birthday, height, weight) FROM stdin;
\.
COPY public.player (id, player_api_id, player_name, player_fifa_api_id, birthday, height, weight) FROM '$$PATH$$/3420.dat';

--
-- Data for Name: player_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player_attributes (id, player_fifa_api_id, player_api_id, date, overall_rating, potential, preferred_foot, attacking_work_rate, defensive_work_rate, crossing, finishing, heading_accuracy, short_passing, volleys, dribbling, curve, free_kick_accuracy, long_passing, ball_control, acceleration, sprint_speed, agility, reactions, balance, shot_power, jumping, stamina, strength, long_shots, aggression, interceptions, positioning, vision, penalties, marking, standing_tackle, sliding_tackle, gk_diving, gk_handling, gk_kicking, gk_positioning, gk_reflexes) FROM stdin;
\.
COPY public.player_attributes (id, player_fifa_api_id, player_api_id, date, overall_rating, potential, preferred_foot, attacking_work_rate, defensive_work_rate, crossing, finishing, heading_accuracy, short_passing, volleys, dribbling, curve, free_kick_accuracy, long_passing, ball_control, acceleration, sprint_speed, agility, reactions, balance, shot_power, jumping, stamina, strength, long_shots, aggression, interceptions, positioning, vision, penalties, marking, standing_tackle, sliding_tackle, gk_diving, gk_handling, gk_kicking, gk_positioning, gk_reflexes) FROM '$$PATH$$/3424.dat';

--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team (id, team_api_id, team_fifa_api_id, team_long_name, team_short_name) FROM stdin;
\.
COPY public.team (id, team_api_id, team_fifa_api_id, team_long_name, team_short_name) FROM '$$PATH$$/3418.dat';

--
-- Data for Name: team_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_attributes (id, team_fifa_api_id, team_api_id, date, buildupplayspeed, buildupplayspeedclass, buildupplaydribbling, buildupplaydribblingclass, buildupplaypassing, buildupplaypassingclass, buildupplaypositioningclass, chancecreationpassing, chancecreationpassingclass, chancecreationcrossing, chancecreationcrossingclass, chancecreationshooting, chancecreationshootingclass, chancecreationpositioningclass, defencepressure, defencepressureclass, defenceaggression, defenceaggressionclass, defenceteamwidth, defenceteamwidthclass, defencedefenderlineclass) FROM stdin;
\.
COPY public.team_attributes (id, team_fifa_api_id, team_api_id, date, buildupplayspeed, buildupplayspeedclass, buildupplaydribbling, buildupplaydribblingclass, buildupplaypassing, buildupplaypassingclass, buildupplaypositioningclass, chancecreationpassing, chancecreationpassingclass, chancecreationcrossing, chancecreationcrossingclass, chancecreationshooting, chancecreationshootingclass, chancecreationpositioningclass, defencepressure, defencepressureclass, defenceaggression, defenceaggressionclass, defenceteamwidth, defenceteamwidthclass, defencedefenderlineclass) FROM '$$PATH$$/3426.dat';

--
-- Name: country_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.country_id_seq', 1, false);


--
-- Name: league_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.league_id_seq', 1, false);


--
-- Name: match_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.match_id_seq', 1, false);


--
-- Name: player_attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.player_attributes_id_seq', 1, false);


--
-- Name: player_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.player_id_seq', 1, false);


--
-- Name: team_attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_attributes_id_seq', 1, false);


--
-- Name: team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_id_seq', 1, false);


--
-- Name: country country_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_name_key UNIQUE (name);


--
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (id);


--
-- Name: league league_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.league
    ADD CONSTRAINT league_name_key UNIQUE (name);


--
-- Name: league league_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.league
    ADD CONSTRAINT league_pkey PRIMARY KEY (id);


--
-- Name: match match_match_api_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_match_api_id_key UNIQUE (match_api_id);


--
-- Name: match match_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_pkey PRIMARY KEY (id);


--
-- Name: player_attributes player_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_attributes
    ADD CONSTRAINT player_attributes_pkey PRIMARY KEY (id);


--
-- Name: player player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_pkey PRIMARY KEY (id);


--
-- Name: player player_player_api_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_player_api_id_key UNIQUE (player_api_id);


--
-- Name: player player_player_fifa_api_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_player_fifa_api_id_key UNIQUE (player_fifa_api_id);


--
-- Name: team_attributes team_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_attributes
    ADD CONSTRAINT team_attributes_pkey PRIMARY KEY (id);


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (id);


--
-- Name: team team_team_api_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_team_api_id_key UNIQUE (team_api_id);


--
-- Name: league league_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.league
    ADD CONSTRAINT league_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.country(id);


--
-- Name: match match_away_player_10_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_10_fkey FOREIGN KEY (away_player_10) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_11_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_11_fkey FOREIGN KEY (away_player_11) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_1_fkey FOREIGN KEY (away_player_1) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_2_fkey FOREIGN KEY (away_player_2) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_3_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_3_fkey FOREIGN KEY (away_player_3) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_4_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_4_fkey FOREIGN KEY (away_player_4) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_5_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_5_fkey FOREIGN KEY (away_player_5) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_6_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_6_fkey FOREIGN KEY (away_player_6) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_7_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_7_fkey FOREIGN KEY (away_player_7) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_8_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_8_fkey FOREIGN KEY (away_player_8) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_player_9_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_player_9_fkey FOREIGN KEY (away_player_9) REFERENCES public.player(player_api_id);


--
-- Name: match match_away_team_api_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_away_team_api_id_fkey FOREIGN KEY (away_team_api_id) REFERENCES public.team(team_api_id);


--
-- Name: match match_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.country(id);


--
-- Name: match match_home_player_10_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_10_fkey FOREIGN KEY (home_player_10) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_11_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_11_fkey FOREIGN KEY (home_player_11) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_1_fkey FOREIGN KEY (home_player_1) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_2_fkey FOREIGN KEY (home_player_2) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_3_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_3_fkey FOREIGN KEY (home_player_3) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_4_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_4_fkey FOREIGN KEY (home_player_4) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_5_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_5_fkey FOREIGN KEY (home_player_5) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_6_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_6_fkey FOREIGN KEY (home_player_6) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_7_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_7_fkey FOREIGN KEY (home_player_7) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_8_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_8_fkey FOREIGN KEY (home_player_8) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_player_9_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_player_9_fkey FOREIGN KEY (home_player_9) REFERENCES public.player(player_api_id);


--
-- Name: match match_home_team_api_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_home_team_api_id_fkey FOREIGN KEY (home_team_api_id) REFERENCES public.team(team_api_id);


--
-- Name: match match_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match
    ADD CONSTRAINT match_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.league(id);


--
-- Name: player_attributes player_attributes_player_api_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_attributes
    ADD CONSTRAINT player_attributes_player_api_id_fkey FOREIGN KEY (player_api_id) REFERENCES public.player(player_api_id);


--
-- Name: player_attributes player_attributes_player_fifa_api_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_attributes
    ADD CONSTRAINT player_attributes_player_fifa_api_id_fkey FOREIGN KEY (player_fifa_api_id) REFERENCES public.player(player_fifa_api_id);


--
-- Name: team_attributes team_attributes_team_api_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_attributes
    ADD CONSTRAINT team_attributes_team_api_id_fkey FOREIGN KEY (team_api_id) REFERENCES public.team(team_api_id);


--
-- PostgreSQL database dump complete
--

